from voice_nav_module import listen_and_process

if __name__ == '__main__':
    while True:
        print(listen_and_process())