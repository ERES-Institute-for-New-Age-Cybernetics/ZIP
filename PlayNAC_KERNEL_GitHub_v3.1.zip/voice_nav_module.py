import speech_recognition as sr
from kernel_router import route_intent_to_module

def listen_and_process():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio)
        return route_intent_to_module(command)
    except:
        return "Could not understand command."